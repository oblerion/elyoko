# Lyoko Engine
3d lyoko game engine,
help to create lyoko world
[elyoko](https://oblerion.itch.io/elyoko)

## Run engine
- win :
```sh
start elyoko.exe
```
- linux :
```sh
./elyoko
```
- macos :
```sh
wine elyoko.exe
```
